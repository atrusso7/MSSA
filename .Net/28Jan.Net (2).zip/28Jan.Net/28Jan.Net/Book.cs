﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _28Jan.Net
{
    public class Book
    {
        public string title, author;
        public int numPages;
    }
}
