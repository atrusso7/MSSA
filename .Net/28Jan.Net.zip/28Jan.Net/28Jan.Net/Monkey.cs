﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _28Jan.Net
{
    class Monkey
    {
        public string Noise()
        {
            return "The monkey goes OOOO OOOO AHHH AHHH!";
        }
    }
}
