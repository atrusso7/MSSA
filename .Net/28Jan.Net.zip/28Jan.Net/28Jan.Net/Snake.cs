﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _28Jan.Net
{
    class Snake
    {
        public string Noise()
        {
            return "The snake goes HISS HISS!";
        }
    }
}
