﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _18Feb.Net
{
    class Feline : Mammal
    {
        public bool HasClaws = true;
        public void FelineHasHair()
        {
            Console.WriteLine("Feline has hair.");
        }
    }
}
