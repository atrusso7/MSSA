﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _18Feb.Net
{
    class Canine : Mammal
    {
        public bool HasClaws = true;

        public void CanineHasHair()
        {
            Console.WriteLine("Canine has hair.");
        }
    }
}
